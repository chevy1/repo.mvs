#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import xbmc
import xbmcgui
import xbmcaddon

win = xbmcgui.Window( 10000 )

class Main:
    
    def __init__(self):
        
        count = 120
        
        #check skin settings
        if xbmc.getSkinDir() == "skin.titan" and xbmc.getCondVisibility("!Skin.HasSetting(msconfigapplied) | !Skin.String(HomeLayout, 3)"):
            xbmc.executebuiltin("RunScript(script.moviestreamer.nl,UPDATESETTINGS)")
        elif xbmc.getSkinDir() != "skin.titan":
            xbmc.executebuiltin("RunScript(script.moviestreamer.nl,INSTALL)")

        while (not xbmc.abortRequested):
            xbmc.sleep(500)
            
            if not xbmc.Player().isPlayingVideo():
                
                # Perform action every minute
                count += 1
                if (count >= 120 and xbmc.getCondVisibility("Window.IsActive(home.xml)")):
                    
                    #check skin settings
                    self.checkConfig()
                    
                    #reset counter
                    count = 0
    
    def checkConfig(self):
        if not win.getProperty("moviestreamerbusy"):
            if xbmc.getSkinDir() == "skin.titan" and not xbmc.getCondVisibility("Skin.HasSetting(msconfigapplied)"):
                xbmc.executebuiltin("RunScript(script.moviestreamer.nl,UPDATESETTINGS)")
            elif xbmc.getSkinDir() == "skin.titan" and xbmc.getCondVisibility("Skin.HasSetting(msconfigapplied)"):
                xbmc.executebuiltin("RunScript(script.moviestreamer.nl,UPDATE)")       

#startup sequence                   
Main()
