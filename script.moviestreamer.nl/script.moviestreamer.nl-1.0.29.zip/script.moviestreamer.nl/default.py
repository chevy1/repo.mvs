import urllib, urllib2, httplib, urlparse, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, sys, time, xbmcvfs
import json
import random
import zipfile
import shutil
import threading, thread

ADDON_ID   = 'script.moviestreamer.nl'
ADDON      =  xbmcaddon.Addon(id=ADDON_ID)
HOME       =  ADDON.getAddonInfo('path')
dialog     =  xbmcgui.Dialog()

USERDATA   =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS     =  xbmc.translatePath(os.path.join('special://home','addons'))
ADDONS_TEMP = os.path.join(HOME,"resources","addons")
UPDATES = os.path.join(HOME,"resources","update")
skin       =  xbmc.getSkinDir()
win = xbmcgui.Window( 10000 )
KODI_VERSION  = int(xbmc.getInfoLabel( "System.BuildVersion" ).split(".")[0])

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92


class GUI(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
        xbmc.log("WINDOW INITIALISED")
        

    def onInit(self):
        pass
        

    def onAction(self, action):
        # Same as normal python Windows.
        if action == ACTION_NAV_BACK or action == ACTION_PREVIOUS_MENU:
            self.close()

    
    def closeDialog(self):
        self.close()
    
    def onClick(self, controlID):
        """
            Notice: onClick not onControl
            Notice: it gives the ID of the control not the control object
        """
        if controlID == 5:
            self.close()
        
        if controlID == 8022:
            self.close()
            
        if controlID == 8033:
            self.close()
                   
        if controlID == 8011:
            if not xbmc.getCondVisibility("Skin.HasSetting(moviestreamer.enablexxx)"):
                dialog = xbmcgui.Dialog()
                d = dialog.numeric(0, 'Pincode:')
                if d == "6969":
                    xbmcgui.Dialog().ok('Erotiek ontgrendeld', 'U heeft nu toegang tot de erotiek add-ons')
                    callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.likuoo","enabled":true},"id":1}')
                    callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.xxtrucoxx","enabled":true},"id":1}')
                    callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.videodevil","enabled":true},"id":1}')
                    callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.erotik","enabled":true},"id":1}')
                    callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.uwc","enabled":true},"id":1}')
                    callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.woodrocket","enabled":true},"id":1}')
                    xbmc.executebuiltin("Skin.SetBool(moviestreamer.enablexxx)")
                else:
                    xbmcgui.Dialog().ok('Pincode onjuist', 'U heeft de verkeerde pincode ingevoerd. De pincode heeft u ontvangen van de MovieStreamer helpdesk')
            else:
                xbmc.executebuiltin("Skin.Reset(moviestreamer.enablexxx)")
                callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.likuoo","enabled":false},"id":1}')
                callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.xxtrucoxx","enabled":false},"id":1}')
                callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.videodevil","enabled":false},"id":1}')
                callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.erotik","enabled":false},"id":1}')
                callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.uwc","enabled":false},"id":1}')
                callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.woodrocket","enabled":false},"id":1}')
        
        if controlID == 8024:
            checkUpdate(True)


    def onFocus(self, controlID):
        pass

def logMsg(msg):
    xbmc.log("MOVIESTREAMER --> " + msg)
        
def installAddons(dp=None):
    
    if dp == None:
        dp = xbmcgui.DialogProgress()
        dp.create('Update voortgang:', 'Bezig met updaten...', '', 'Een ogenblik geduld')
    
    downloadList = list()
        
    addonsFile = xbmc.translatePath(os.path.join(ADDONS_TEMP, "addons.txt"))
    infile = open(addonsFile, 'r')
    data = infile.read()
    infile.close()
    for line in data.splitlines():
        if line and not line.startswith("#") and not line.startswith(" "):
            downloadList.append(line)
            
    #add skin download
    downloadList.append("skin.titan;%s" %getSkinDownloadUrl())
    
    #download all addons (if needed)
    for item in downloadList:
        
        if ";" in item:
            #url is supplied - direct download
            name = item.split(";")[0]
            url = item.split(";")[1]
            itempath = xbmc.translatePath(os.path.join(ADDONS, name))
            if not os.path.exists(itempath):
                download(url,dp)
        else:
            #no downloadurl so search the addon in superrepo
            itempath = xbmc.translatePath(os.path.join(ADDONS, item))
            if not os.path.exists(itempath):
                downloadAddon(item,dp)       
           
    #install downloaded addons
    installDownloads(dp)
    
    #trigger update
    xbmc.executebuiltin( 'UpdateAddonRepos' )            
    xbmc.executebuiltin( 'UpdateLocalAddons' )
    
    #process all dependencies
    for item in downloadList:
        downloadDeps(item,dp)
        
    #install downloaded dependencies
    installDownloads(dp)    
    
    #trigger update
    xbmc.executebuiltin( 'UpdateAddonRepos' )            
    xbmc.executebuiltin( 'UpdateLocalAddons' )
        
def installFull():

    ret = dialog.yesno(heading="Alle instellingen installeren/herstellen", line1="Weet u zeker dat u alles wilt herstellen naar de aanbevolen MovieStreamer instellingen ?", nolabel="Nee", yeslabel="Ja")
    if ret:
        dp = xbmcgui.DialogProgress()
        dp.create('Installatie voortgang:', 'Bezig met installeren en herstellen', '', 'Een ogenblik geduld')
        
        #install Addons
        installAddons(dp)
        
        #install addondata
        source_dir = os.path.join(HOME,"resources","userdata")
        file = os.path.join(source_dir,"addondata.zip")
        if os.path.exists(file):
            unzip(file, ADDON_DATA, dp)
                        
        #trigger update
        xbmc.executebuiltin( 'UpdateAddonRepos' )            
        xbmc.executebuiltin( 'UpdateLocalAddons' )
        xbmc.sleep(8000)
        
        #install userdata
        file = os.path.join(source_dir,"userdata.zip")
        if os.path.exists(file):
            unzip(file, USERDATA, dp)
        
        #remove any updates
        dirs, files = xbmcvfs.listdir(UPDATES)
        for fileName in files:
            xbmcvfs.delete(fileName)
        
        dp.close()
        #restore gui settings
        updateKodiSettings()
        installSkinShortCuts()
        xbmcgui.Dialog().ok('Installatie succesvol', 'Uw MovieStreamer is succesvol hersteld naar de aanbevolen instellingen!', 'Uw moviestreamer wordt nu opnieuw opgestart... ')
        xbmc.executebuiltin("RestartApp")

def confirmDialog(waitforDialog=5):
    for i in range(waitforDialog):
        if not xbmc.getCondVisibility("Window.IsActive(yesnodialog) | Window.IsActive(okdialog)"):
            xbmc.sleep(500)
        else:
            break
    if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
        logMsg("Confirm OK dialog...")
        xbmc.executebuiltin( 'Action(select)' )
        xbmc.sleep(500)
    elif xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
        logMsg("Confirm yesno dialog...")
        xbmc.executebuiltin( 'Control.SetFocus(11)' )
        xbmc.sleep(500)
        xbmc.executebuiltin( 'Action(select)' )
        xbmc.sleep(500)

def callKodiJson(commandstr,waitforDialog=0):
    xbmc.executebuiltin( "ActivateWindow(busydialog)" )
    logMsg("Call Kodi Json--> " + commandstr)
    thread.start_new_thread(xbmc.executeJSONRPC,(commandstr,))
    confirmDialog(waitforDialog)
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        
def updateKodiSettings():
    xbmc.executebuiltin( "ActivateWindow(busydialog)" )
    
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"locale.country","value":"NL"}}')
    if not xbmc.getInfoLabel("System.Language") == "Dutch":
        callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"Dutch"}}',120)
    
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Dutch"}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"services.devicename","value":"moviestreamer"}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.opensubtitles"}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.podnapisi"}}')
    languages = []
    languages.append("Dutch")
    json_array = json.dumps(languages)
    result = callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":' + json_array + '}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"filelists.showaddsourcebuttons","value":true}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.enablerssfeeds","value":false}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.soundskin","value":"resource.uisounds.titan.modern"}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"powermanagement.shutdownstate","value":1}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"audiooutput.streamsilence","value":0}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"weather.addon","value":"weather.yahoo"}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"weather.currentlocation","value":1}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"musicplayer.visualisation","value":"none"}}')
    callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"musicplayer.autoplaynextitem","value":true}}')
    
    if xbmc.getCondVisibility("System.Platform.Android"):
        callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"services.zeroconf","value":true}}')
        xbmc.sleep(1000)
        callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"services.airplay","value":true}}',120)
    
    #skin settings
    installSkinShortCuts()
    text_file_path = os.path.join(HOME,"resources","userdata","guisettings.txt")
    f = open(text_file_path,"r")
    skinsettings = eval(f.read())
    f.close()
    
    if xbmc.getSkinDir() != "skin.titan":
        logMsg("Set Kodi skin to skin.titan...")
        callKodiJson('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.titan"}}',120)
    
    logMsg("Apply skin setings...")
    for skinsetting in skinsettings:
        if skinsetting[0] == "string":
            if skinsetting[2] is not "":
                xbmc.executebuiltin("Skin.SetString(%s,%s)" % (skinsetting[1], skinsetting[2]))
            else:
                xbmc.executebuiltin("Skin.Reset(%s)" % skinsetting[1])
        elif skinsetting[0] == "bool":
            if skinsetting[2] == "true":
                xbmc.executebuiltin("Skin.SetBool(%s)" % skinsetting[1])
            else:
                xbmc.executebuiltin("Skin.Reset(%s)" % skinsetting[1])
    
    #remove some old addons
    confirmDialog(30)
    removeAddon("service.subtitles.nlondertitels")
    removeAddon("plugin.video.beeg")
    removeAddon("plugin.video.beeg.com")
    removeAddon("plugin.video.drtuber")
    
    #finish
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
    
def removeAddon(name):
    callKodiJson('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":false},"id":1}' %name)
    path = xbmc.translatePath(os.path.join(ADDONS, name))
    if os.path.exists(path):
        shutil.rmtree(path)

def installSkinShortCuts():
    #install skin shortcuts
    logMsg("Install skin shortcuts...")
    source_dir = os.path.join(HOME,"resources","userdata")
    file = os.path.join(source_dir,"shortcuts.zip")
    if os.path.exists(file):
        unzip(file, ADDON_DATA)

def checkUpdate(manualRun=False):
    
    #fix the skin if needed
    fixSkin()
    
    #install forced update
    update = xbmc.translatePath(os.path.join(UPDATES, "update.txt"))
    update_manual = xbmc.translatePath(os.path.join(UPDATES, "update_manual.txt"))
    if (os.path.exists(update) or (manualRun and os.path.exists(update_manual))):
        
        ret = dialog.yesno(heading="Update beschikbaar!", line1="Er is een update beschikbaar voor uw Moviestreamer. Wilt u deze update nu toepassen ? Indien u nee selecteert kunt u altijd nog achteraf via instellingen deze update toepassen.", nolabel="Nee", yeslabel="Ja")
        if ret:
            installAddons()
            
            #set Kodi Settings
            updateKodiSettings()
            
            #install addondata
            source_dir = os.path.join(HOME,"resources","userdata")
            file = os.path.join(source_dir,"addondata.zip")
            if os.path.exists(file):
                unzip(file, ADDON_DATA)
            
            #install skin shortcuts
            installSkinShortCuts()
                
            #fix the skin if needed
            fixSkin()

            xbmcvfs.delete(update)
            xbmcvfs.delete(update_manual)
            xbmcgui.Dialog().ok('Update succesvol', 'Uw MovieStreamer is succesvol bijgewerkt naar de laatste versie')
            xbmc.executebuiltin( 'ReloadSkin' )
        else:
            #ignore the update, user must install it manually
            xbmcvfs.rename(update, update_manual)
    else: 
        xbmc.executebuiltin( 'UpdateAddonRepos' )            
        xbmc.executebuiltin( 'UpdateLocalAddons' )
        if manualRun:
            xbmcgui.Dialog().ok('Update succesvol', 'Uw MovieStreamer is succesvol bijgewerkt naar de laatste versie')

def fixSkin():
    #skin update check
    itempath = xbmc.translatePath(os.path.join(ADDONS, "skin.titan", "media", "Textures.xbt"))
    if not os.path.exists(itempath):
        dp = xbmcgui.DialogProgress()
        dp.create('Installatie voortgang:', 'Bezig met installeren en herstellen', '', 'Een ogenblik geduld')
        download(getSkinDownloadUrl(),dp)
        installAddons(dp)
        xbmc.executebuiltin( 'ReloadSkin' )

def getSkinDownloadUrl():
    if KODI_VERSION == 15:
        return getDownloadUrlKodiRepo("skin.titan","isengard")
    elif KODI_VERSION == 16:
        return getDownloadUrlKodiRepo("skin.titan","jarvis")
    elif KODI_VERSION == 17:
        return getDownloadUrlKodiRepo("skin.titan","krypton")
    else:
        return getDownloadUrlKodiRepo("skin.titan","helix")
        
def unzip(_in, _out, dp=None):

    zin = zipfile.ZipFile(_in)
    nFiles = float(len(zin.infolist()))
    count  = 0

    for item in zin.infolist():
        count += 1
        update = count / nFiles * 100
        if dp != None:
            dp.update(int(update))
        try:
            zin.extract(item, _out)
        except:
            pass

    return True    

def installDownloads(dp=None):
    #install all downloaded addons
    source_dir = os.path.join(HOME,"resources","addons")
    dirs, files = xbmcvfs.listdir(source_dir)
    for fileName in files:
        if ".zip" in fileName:
            file = os.path.join(source_dir,fileName)
            try:
                unzip(file, ADDONS, dp)
            except Exception as e:
                xbmc.log("error while unzipping file %s - exception: %s" %(fileName, str(e)))
            xbmcvfs.delete(file)

def downloadAddon(addonName,dp = None):
    
    if addonName == "xbmc.json" or addonName == "xbmc.addon" or addonName == "script.module.pil" or addonName == "kodi.resource":
        return
    
    success = False
    
    #try official repo first
    url = getDownloadUrlKodiRepo(addonName)
    if url: 
        logMsg("Found url for %s on official repo, starting download..." %addonName)
        success = download(url,dp)
    
    #tvaddons
    if not success:
        url, repourl = getDownloadUrlTvAddons(addonName)
        if url:
            logMsg("Found url for %s on TVAddons repo, starting download..." %addonName)
            success = download(url,dp)
        if repourl:
            logMsg("Found REPO url for %s on TVaddons repo, starting download..." %addonName)
            download(repourl,dp)
    
    #superrepo
    if not success:
        url = getDownloadUrlSuperRepo(addonName)
        if url:
            logMsg("Found url for %s on Superrepo, starting download..." %addonName)
            success = download(url,dp)
        
    if not url or not success:
        logMsg( "Download for %s failed on all sources!" %addonName )
            
def getDownloadUrlSuperRepo(addonName):
    downloadUrl = ""
    try:
        req = urllib2.Request("https://superrepo.org/kodi/addon/%s/" %addonName)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link     = response.read()
        response.close()
        link =  link.replace('\r','').replace('\n','').replace('\t','')
        urls = re.compile('downloadurl="(.+?)"').findall(link)
        if urls:
            downloadUrl = urls[0].replace("v5","v7")
            logMsg("Found url for addon %s on Superrepo--> %s" %(addonName,downloadUrl))
    except Exception as e:
        if not "HTTP Error 404" in str(e):
            logMsg("Error in getDownloadUrlSuperRepo for addon %s - Exception: %s" %(addonName,str(e)))
    return downloadUrl
    
def getDownloadUrlTvAddons(addonName):
    downloadUrl = ""
    repourl = ""
    try:
        req = urllib2.Request("https://www.tvaddons.ag/kodi-addons/show/%s/" %addonName)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link     = response.read()
        response.close()
        link =  link.replace('\r','').replace('\n','').replace('\t','')
        repourl=re.compile('Repository:</strong> <a href="(.+?)"').findall(link)[0]; repourl=repourl.replace('https://github','http://github'); print ['repourl',repourl];
        downloadUrl=re.compile('Download:</strong><br /><a href="(.+?)"').findall(link)[0]; print ['downloadUrl',downloadUrl];
    except Exception as e:
        if not "HTTP Error 404" in str(e):
            logMsg("Error in getDownloadUrlTvAddons for addon %s - Exception: %s" %(addonName,str(e)))
    return downloadUrl,repourl
   
def getDownloadUrlKodiRepo(addonName,mirrorversion="jarvis"):
    downloadUrl = ""
    lastversion = 0
    mirrorurl = "http://mirrors.kodi.tv/addons/%s/%s/" %(mirrorversion,addonName)
    try:
        req = urllib2.Request(mirrorurl)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link     = response.read()
        response.close()
        link =  link.replace('\r','').replace('\n','').replace('\t','')
        for item in re.compile('<a href="(.+?)"').findall(link):
            if item.endswith(".zip"):
                version = int(item.split("-")[-1].replace(".","").replace("zip",""))
                if version > lastversion:
                    downloadUrl = mirrorurl + item
                    lastversion = version
        if downloadUrl: 
            logMsg("Found url for addon %s on Kodi repo--> %s" %(addonName,downloadUrl))
    except Exception as e:
        if not "HTTP Error 404" in str(e):
            logMsg("Error in getDownloadUrlKodiRepo for addon %s - Exception: %s" %(addonName,str(e)))
    return downloadUrl
        
def download(url,dp = None):
    dp.update(0)
    try:
        dest = url
        dest = dest.rsplit('/',1)
        dest = dest[1]
        dest = dest.rsplit('&',1)
        dest = dest[0]
        dest = dest.rsplit('?',1)
        dest = dest[0]
        orgdest = dest
        dest = os.path.join(ADDONS_TEMP,dest)
        if not xbmcvfs.exists(url):
            logMsg("Download FAILED for %s" %url)
            return False
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
        logMsg("Download succeeded for %s" %url)
    except Exception as e:
        xbmc.log("Fout opgetreden bij downloaden van %s - Exception: %s" %(url, str(e)))
        return False
    return True
 
def _pbhook(numblocks, blocksize, filesize, url, dp):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        raise Exception("Geannuleerd")
        dp.close()    
        
def downloadDeps(addonname,dp):

    addonname = addonname.replace(".zip","")
    depends = xbmc.translatePath(os.path.join(ADDONS, addonname, 'addon.xml'))    
    if os.path.exists(depends):
        source  = open(depends, mode = 'r')
        link    = source.read()
        source.close ()

        dmatch = re.compile('import addon="(.+?)"').findall(link)
        for requires in dmatch:
            if not 'xbmc.python' in requires:
                dependspath = xbmc.translatePath(os.path.join(ADDONS, requires))
                if not os.path.exists(dependspath):
                    downloadAddon(requires,dp)
                    
def doMaintenance():
    #clean crash logs
    dirs, files = xbmcvfs.listdir("special://temp/")
    for file in files:
        if "stacktrace" in file or "crashlog" in file:
            xbmcvfs.delete("special://temp/" + file)
    #delete packages
    dirs, files = xbmcvfs.listdir("special://home/addons/packages/")
    for file in files:
        xbmcvfs.delete("special://home/addons/packages/" + file)
    xbmcgui.Dialog().ok('Onderhoud succesvol', 'Uw moviestreamer is nu opgeschoond...')
    xbmc.executebuiltin('StartAndroidActivity("com.cmcm.cleanmaster.tv")')
                    
#script init
action = ""
argument1 = ""
argument2 = ""
argument3 = ""

# get arguments
try:
    action = str(sys.argv[1])
except: 
    pass

try:
    argument1 = str(sys.argv[2])
except: 
    pass

try:
    argument2 = str(sys.argv[3])
except: 
    pass

try:
    argument3 = str(sys.argv[4])
except: 
    pass  

# select action
if action == "INSTALL":
    win.setProperty("moviestreamerbusy","busy")
    installFull()
    win.clearProperty("moviestreamerbusy")
elif action == "MAINTENANCE":
    win.setProperty("moviestreamerbusy","busy")
    doMaintenance()
    win.clearProperty("moviestreamerbusy")
elif action == "UPDATE":
    win.setProperty("moviestreamerbusy","busy")
    checkUpdate()
    win.clearProperty("moviestreamerbusy")
elif action == "UPDATESETTINGS":
    win.setProperty("moviestreamerbusy","busy")
    updateKodiSettings()
    win.clearProperty("moviestreamerbusy")
else:
    #install config if not titan skin
    if not xbmc.getCondVisibility("Skin.HasSetting(IsTitanSkin)"):
        win.setProperty("moviestreamerbusy","busy")
        installFull()
        win.clearProperty("moviestreamerbusy")
    else:
        # fix logo location
        xbmc.executebuiltin("Skin.SetString(CustomLogoImage,special://home/addons/script.moviestreamer.nl/resources/skins/default/media/MS_logo.png)")
        ui = GUI("SimpleSettings.xml", HOME, "default", "1080i")
        ui.doModal()
        del ui